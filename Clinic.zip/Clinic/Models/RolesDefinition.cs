﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Clinic.Models
{
    public class RolesDefinition
    {
        public const string CanManageClinicRole = "CanManageClinic";
    }
}